install.packages("tidyverse")
library(tidyverse)

df <- read.csv("202201-divvy-tripdata.csv")

head(df)

glimpse(df) #look for datatypes

unique(df$rideable_type)
unique(df$member_casual)

#ensure all data is within the month of Jan as expected
range(df$started_at)
range(df$ended_at)

#get an idea of outlier values for location/distance
range(df$start_lat)
range(df$end_lat, na.rm = TRUE) #have to remove NAs for this to work
range(df$start_lng)
range(df$end_lng, na.rm = TRUE)
