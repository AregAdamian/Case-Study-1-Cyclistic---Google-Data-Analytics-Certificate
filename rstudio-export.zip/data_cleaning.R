#Change date columns to datetime
df$started_at <- as.POSIXct(df$started_at)
df$ended_at <- as.POSIXct(df$ended_at)

df <- df %>%
  mutate(dist_km = (sqrt((start_lat - end_lat)^2 + (start_lng - end_lng)^2))*110.95) %>%
  mutate(ride_length_mins = abs(difftime(df$started_at, df$ended_at, units ='mins'))) %>%
  mutate(time = format(as.POSIXct(df$started_at), format="%H:%M"))
  mutate(weekday = weekdays(started_at)) %>% 
  mutate(same_station = ifelse(start_station_id == end_station_id, 1, 0)) %>% 
  mutate(weekday_type = ifelse(weekday == "Saturday" | weekday == "Sunday", "weekend", "weekday")) %>% 
  drop_na() %>% 
  select(ride_id, dist_km, ride_length_mins, weekday, weekday_type, rideable_type, member_casual, same_station) %>%
  filter(ride_length_mins <1500, dist_km<30) #keeps it ~within 48 hrs