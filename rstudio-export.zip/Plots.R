df %>% 
  ggplot (aes(member_casual, ride_length_mins)) +
    geom_bar(aes(fill=member_casual), stat="summary", fun="mean")+
    facet_wrap(~weekday_type)+
    labs(title="Trip Duration")+
    xlab("Member Type") + ylab("Average trip duration (mins)")+
    theme(axis.text.x = element_text(angle=30))

df %>% 
  ggplot (aes(member_casual, dist_km)) +
  geom_bar(aes(fill=member_casual), stat="summary", fun="mean")+
  facet_wrap(~weekday_type)+
  labs(title="Trip Distance")+
  xlab("Member Type") + ylab("Average trip length (kms)")+
  theme(axis.text.x = element_text(angle=30))